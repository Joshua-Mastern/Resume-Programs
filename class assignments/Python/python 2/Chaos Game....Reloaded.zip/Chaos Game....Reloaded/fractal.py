########################################################################
#Name: Joshua Brack                                                    #
#Descr: file to be importated by the main file of Chaos game...reloaded#
########################################################################



class Point(object):
        # write your code for the point class here (and subsequently remove this comment)
        def __init__(self, x = 0.0, y = 0.0):
                self.x = x
                self.y = y

        #accessor for x component
        @property
        def x(self):
                return self._x

        #mutator (setter) for x component
        @x.setter
        def x(self, value):
                self._x = float(value)

        #accessor for y component
        @property
        def y(self):
                return self._y

        #mutator(setter) for y component
        @y.setter
        def y(self, value):
                self._y = float(value)
        #calculate distance from this point and another given point
        def dist(self, other):
                return (((other.x-self.x)**2)+((other.y-self.y)**2))**(1/2.0)
        #calculate midpoint between this point and another given point
        def midpt(self, other):
                x1 = self.x
                y1 = self.y
                x2 = other.x
                y2 = other.y
                midx = ((x2+x1)/2.0)
                midy = ((y2+y1)/2.0)
                midPoint = Point(midx, midy)
                return midPoint

        def interpt(self, other, r):
                # make sure that the distance ratio is expressed from a
                # smaller component value to a larger one
                # first, the x-component
                rx = r
                if (self.x > other.x):
                        rx = 1.0 - r
                # next, the y-component
                ry = r
                if (self.y > other.y):
                        ry = 1.0 - r
                # calculate the new point's coordinates
                # the difference in the components (distance between the
                # points) is first scaled by the specified distance ratio
                # the minimum of the components is then added back in order
                # to obtain the coordinates in between the two points (and
                # not with respect to the origin)
                x = abs(self.x - other.x) * rx + min(self.x, other.x)
                y = abs(self.y - other.y) * ry + min(self.y, other.y)
                return Point(x, y)

        def __str__(self):
                return "({},{})".format(self.x,self.y)


class Fractal(object):
        #superclass
        def __init__(self, dimensions):
                self.dimensions = dimensions
                self.num_points = 50000
                #distance ratio
                self.r = 0.5


        def frac_x(self, r):
                return int((self.dimensions["max_x"] - self.dimensions["min_x"]) * r) + self.dimensions["min_x"]



        def frac_y(self, r):
                return int((self.dimensions["max_y"] - self.dimensions["min_y"]) * r) + self.dimensions["min_y"]


class SierpinskiTriangle(Fractal):

        def __init__(self, dimensions):

                Fractal.__init__(self, dimensions)
                #list of vertices for this fractal
                self.vertices = [Point(self.dimensions["mid_x"],self.dimensions["min_y"]), Point(self.dimensions["min_x"], \
                                self.dimensions["max_y"]), Point(self.dimensions["max_x"], self.dimensions["max_y"])]

class SierpinskiCarpet(Fractal):
        def __init__(self, dimensions):

                Fractal.__init__(self, dimensions)
                #list of vertices for this fractal
                self.vertices = [Point(self.dimensions["min_x"],self.dimensions["min_y"]), Point(self.dimensions["mid_x"], \
                                self.dimensions["min_y"]), Point(self.dimensions["max_x"], self.dimensions["min_y"]),\
                                Point(self.dimensions["min_x"], self.dimensions["mid_y"]), Point(self.dimensions["max_x"], self.dimensions["mid_y"]),\
                                 Point(self.dimensions["min_x"], self.dimensions["max_y"]), Point(self.dimensions["mid_x"], self.dimensions["max_y"]),\
                                 Point(self.dimensions["max_x"], self.dimensions["max_y"])]
                self.num_points = 100000
                self.r = 0.66

class Hexagon(Fractal):
        def __init__(self, dimensions):

                Fractal.__init__(self, dimensions)
                #list of vertices for this fractal
                self.vertices = [Point(self.dimensions["mid_x"], self.dimensions["min_y"]),\
                                 Point(self.dimensions["min_x"], self.frac_y(0.25)),\
                                 Point(self.dimensions["max_x"], self.frac_y(0.25)),\
                                 Point(self.dimensions["min_x"], self.frac_y(0.75)),\
                                 Point(self.dimensions["max_x"], self.frac_y(0.75)),\
                                 Point(self.dimensions["mid_x"], self.dimensions["max_y"])]
                self.num_points = 50000
                self.r = 0.665
