###################################################################################
#Name: Joshua Brack                                                               #
#Date: 5/9/2019                                                                   #
#Description: Main class that imports fractal modules in order to build a variety #
#               of intereting shapes via canvas                                   #              
#Chosen fractals: SierpinskiTriangle; SierpinskiCarpet; Hexagon                   #
###################################################################################



from Tkinter import *
from random import randint
from fractal import *

# the default size of the canvas is 600x520
WIDTH = 600
HEIGHT = 520


class ChaosGame(Canvas):
        def __init__(self, master):

                Canvas.__init__(self, master, bg = "white")
                self.pack(fill = BOTH, expand = 1)
                
                self.dimensions = {"width" : WIDTH, "height" : HEIGHT,\
                "min_x" : 5, "max_x" : WIDTH-5, "min_y" : 5, "max_y":HEIGHT-5\
                ,"mid_x" : None, "mid_y" : None}

                #mid_x and mid_y rely on values within dimensions to get their value
                self.dimensions["mid_x"] = (self.dimensions["min_x"]+self.dimensions["max_x"])/2
                self.dimensions["mid_y"] = (self.dimensions["min_y"]+self.dimensions["max_y"])/2
                
                self.vertex_radius = 2
                self.vertex_color = "red"
                self.point_radius = 0
                self.point_color = "black"
                self.fractal = None

        def make(self, f):
                #determine which fractal we are making
                if(f == "SierpinskiTriangle"):
                        self.fractal = SierpinskiTriangle(self.dimensions)
                elif(f == "SierpinskiCarpet"):
                        self.fractal = SierpinskiCarpet(self.dimensions)
                elif(f == "Hexagon"):
                        self.fractal = Hexagon(self.dimensions)
                
                #plot vertices
                for i in range(len(self.fractal.vertices)):
                        self.plot_point(self.fractal.vertices[i], self.vertex_color, self.vertex_radius)
                        
                #plot intermedite points
                temp = self.fractal.vertices[0].interpt(self.fractal.vertices[1],self.fractal.r)
                self.plot_point(temp, self.point_color, self.point_radius)                        

                for i in range(self.fractal.num_points-1): #one point has already been plotted
                        temp = temp.interpt(self.fractal.vertices[randint(0, len(self.fractal.vertices)-1)], self.fractal.r)
                        self.plot_point(temp, self.point_color, self.point_radius)
                        
        def plot_point(self, point, color, radius):
                self.create_oval(point.x-radius, point.y-radius, point.x+radius, \
                                 point.y+radius, fill = color, outline = color)        
                




# the implemented fractals
FRACTALS = [ "SierpinskiTriangle", "SierpinskiCarpet",\
 "Hexagon"]


# create the fractals in individual (sequential) windows
for f in FRACTALS:
        window = Tk()
        window.geometry("{}x{}".format(WIDTH, HEIGHT))
        window.title("The Chaos Game...Reloaded")
        # create the game as a Tkinter canvas inside the window
        s = ChaosGame(window)
        # make the current fractal
        s.make(f)
        # wait for the window to close
        window.mainloop()

