# Tryna_Get_An_A_On_BattleBots
CSC 132 Raspberry Pi Final Project KIREMIRE

All that must be downloaded is the loadout.zip file. It contains all the needed data. Additionally each file (minus keyboard module)
is posted by itself withint this repository.

REMEMBER:
1) run main file with administrative authority- keyboard module needs that
2)if you get files individually (instead of loadout.zip) you'll have to remember to get the keyboard module as well(its not posted except
for in loadout.zip.)
